# 🔍 PESQUISA MINUCIOSA E ABRANGENTE: CORES HARDCODED

## 📊 **RESULTADO DA PESQUISA**

**🚨 PROBLEMA IDENTIFICADO**: Foram encontradas **757 cores hardcoded** no sistema!

---

## 🎯 **TIPOS DE CORES HARDCODED IDENTIFICADAS**

### **🔴 TIPO 1: Cores Hexadecimais (#XXXXXX)**

**📊 QUANTIDADE**: 757 ocorrências
**🔍 EXEMPLOS**:

- `#29ABE2` (Azul primário)
- `#90EE90` (Verde secundário)
- `#2E8B57` (Verde escuro)
- `#4682B4` (Azul acinzentado)
- `#FF6347` (Laranja)

### **🔴 TIPO 2: Cores RGBA**

**📊 QUANTIDADE**: 35 ocorrências
**🔍 EXEMPLOS**:

- `rgba(255, 255, 255, 0.95)` (Branco com transparência)
- `rgba(0, 0, 0, 0.1)` (Preto com transparência)
- `rgba(41, 171, 226, 0.1)` (Azul com transparência)

### **🔴 TIPO 3: Cores Textuais**

**📊 QUANTIDADE**: 19 ocorrências
**🔍 EXEMPLOS**:

- `white` (Branco)
- `black` (Preto)
- `red` (Vermelho)
- `green` (Verde)
- `blue` (Azul)

### **🔴 TIPO 4: Valores CSS Especiais**

**📊 QUANTIDADE**: 10 ocorrências
**🔍 EXEMPLOS**:

- `transparent` (Transparente)
- `inherit` (Herdar)
- `initial` (Inicial)
- `unset` (Não definido)

---

## 📋 **TABELA DE CHECKLIST PARA CORREÇÃO**

| **Arquivo**                      | **Diretório**                   | **Tipo de Hardcoded**        | **Quantidade** | **Solução Proposta**                     |
| -------------------------------- | ------------------------------- | ---------------------------- | -------------- | ---------------------------------------- |
| `esocial-domestico-completo.tsx` | `src/pages/`                    | Hexadecimal + RGBA + Textual | 15             | Sistema de fallback hierárquico com tema |
| `time-clock-simple.tsx`          | `src/pages/`                    | Hexadecimal                  | 4              | Sistema de fallback hierárquico com tema |
| `welcome-tutorial.tsx`           | `src/pages/`                    | Hexadecimal + RGBA + Textual | 12             | Sistema de fallback hierárquico com tema |
| `login.tsx`                      | `src/pages/`                    | Hexadecimal                  | 8              | Sistema de fallback hierárquico com tema |
| `esocial-integration.tsx`        | `src/pages/`                    | Hexadecimal + RGBA + Textual | 25             | Sistema de fallback hierárquico com tema |
| `payroll-management.tsx`         | `src/pages/`                    | Hexadecimal                  | 1              | Sistema de fallback hierárquico com tema |
| `communication.tsx`              | `src/pages/`                    | Hexadecimal + Textual        | 3              | Sistema de fallback hierárquico com tema |
| `alert-management.tsx`           | `src/pages/`                    | Hexadecimal + Textual        | 8              | Sistema de fallback hierárquico com tema |
| `antifraude.tsx`                 | `src/pages/admin/`              | Hexadecimal + RGBA           | 15             | Sistema de fallback hierárquico com tema |
| `PayrollTransferCard/index.tsx`  | `src/components/`               | Hexadecimal                  | 1              | Sistema de fallback hierárquico com tema |
| `ActionButton/index.tsx`         | `src/components/`               | Hexadecimal + Textual        | 5              | Sistema de fallback hierárquico com tema |
| `InfoCard/index.tsx`             | `src/components/`               | Hexadecimal                  | 1              | Sistema de fallback hierárquico com tema |
| `StatusCard/index.tsx`           | `src/components/`               | Hexadecimal                  | 1              | Sistema de fallback hierárquico com tema |
| `colors-simplificado.ts`         | `src/design-system/tokens/`     | Hexadecimal                  | 20             | Referenciar DEFAULT_COLORS               |
| `colors.ts`                      | `src/design-system/tokens/`     | Hexadecimal                  | 30             | Referenciar DEFAULT_COLORS               |
| `Input.tsx`                      | `src/design-system/components/` | Hexadecimal + Textual        | 2              | Sistema de fallback hierárquico com tema |
| `Button.tsx`                     | `src/design-system/components/` | RGBA + Textual               | 2              | Sistema de fallback hierárquico com tema |
| `GeofencingModal.tsx`            | `src/components/`               | RGBA + Textual               | 3              | Sistema de fallback hierárquico com tema |
| `GroupSelectionModal.tsx`        | `src/components/`               | Textual                      | 2              | Sistema de fallback hierárquico com tema |
| `MultiStepForm/index.tsx`        | `src/components/`               | Textual + Especial           | 2              | Sistema de fallback hierárquico com tema |
| `NotificationBadge/index.tsx`    | `src/components/`               | Textual                      | 8              | Sistema de fallback hierárquico com tema |
| `UnifiedButton/index.tsx`        | `src/components/`               | Especial                     | 5              | Sistema de fallback hierárquico com tema |
| `FilterSection/index.tsx`        | `src/components/`               | RGBA                         | 2              | Sistema de fallback hierárquico com tema |
| `PageHeader/index.tsx`           | `src/components/`               | RGBA                         | 1              | Sistema de fallback hierárquico com tema |
| `TopBar/index.tsx`               | `src/components/`               | RGBA                         | 2              | Sistema de fallback hierárquico com tema |

---

## 🎯 **PLANEJAMENTO PARA CORREÇÃO**

### **✅ FASE 1: ANÁLISE E PRIORIZAÇÃO**

**🎯 OBJETIVO**: Analisar e priorizar as correções baseado na criticidade

**📋 AÇÕES**:

1. **Identificar arquivos críticos** (componentes base, design system)
2. **Priorizar por impacto** (arquivos mais usados primeiro)
3. **Mapear dependências** (arquivos que dependem de outros)

### **✅ FASE 2: CORREÇÃO DO DESIGN SYSTEM**

**🎯 OBJETIVO**: Corrigir tokens de cores e componentes base

**📋 ARQUIVOS PRIORITÁRIOS**:

1. `src/design-system/tokens/colors.ts`
2. `src/design-system/tokens/colors-simplificado.ts`
3. `src/design-system/components/Button.tsx`
4. `src/design-system/components/Input.tsx`

**🔧 ESTRATÉGIA**:

- Referenciar `DEFAULT_COLORS` do arquivo centralizado
- Eliminar cores hardcoded
- Manter compatibilidade com temas

### **✅ FASE 3: CORREÇÃO DE COMPONENTES**

**🎯 OBJETIVO**: Corrigir componentes reutilizáveis

**📋 ARQUIVOS PRIORITÁRIOS**:

1. `src/components/ActionButton/index.tsx`
2. `src/components/NotificationBadge/index.tsx`
3. `src/components/UnifiedButton/index.tsx`
4. `src/components/GeofencingModal.tsx`
5. `src/components/GroupSelectionModal.tsx`

**🔧 ESTRATÉGIA**:

- Sistema de fallback hierárquico
- Usar cores do tema ativo
- Manter funcionalidade

### **✅ FASE 4: CORREÇÃO DE PÁGINAS**

**🎯 OBJETIVO**: Corrigir páginas específicas

**📋 ARQUIVOS PRIORITÁRIOS**:

1. `src/pages/login.tsx`
2. `src/pages/dashboard.tsx`
3. `src/pages/welcome-tutorial.tsx`
4. `src/pages/esocial-domestico-completo.tsx`
5. `src/pages/time-clock-simple.tsx`

**🔧 ESTRATÉGIA**:

- Sistema de fallback hierárquico
- Usar cores do tema ativo
- Manter UX/UI

### **✅ FASE 5: CORREÇÃO DE PÁGINAS ADMINISTRATIVAS**

**🎯 OBJETIVO**: Corrigir páginas administrativas

**📋 ARQUIVOS PRIORITÁRIOS**:

1. `src/pages/admin/antifraude.tsx`
2. `src/pages/esocial-integration.tsx`
3. `src/pages/payroll-management.tsx`
4. `src/pages/communication.tsx`
5. `src/pages/alert-management.tsx`

**🔧 ESTRATÉGIA**:

- Sistema de fallback hierárquico
- Usar cores do tema ativo
- Manter funcionalidade administrativa

---

## 🔧 **ESTRATÉGIA DE CORREÇÃO**

### **✅ SISTEMA DE FALLBACK HIERÁRQUICO**

**🔧 IMPLEMENTAÇÃO**:

```tsx
// ✅ CORRETO: Sistema de fallback hierárquico
color: props.$theme?.colors?.textSecondary ||
  props.$theme?.colors?.text ||
  props.$theme?.colors?.primary ||
  props.$theme?.colors?.secondary;
```

**✅ VANTAGENS**:

- **Usa apenas cores do tema**
- **Fallback seguro**
- **Adequado à centralização**
- **Adequado ao tema**

### **✅ REFERENCIAÇÃO AO DEFAULT_COLORS**

**🔧 IMPLEMENTAÇÃO**:

```tsx
// ✅ CORRETO: Referenciar DEFAULT_COLORS
success: DEFAULT_COLORS.status?.success || '#10B981',
```

**✅ VANTAGENS**:

- **Centralizado**
- **Consistente**
- **Gerenciável**

### **✅ INTEGRAÇÃO COM BANCO DE DADOS**

**🔧 IMPLEMENTAÇÃO**:

```tsx
// ✅ CORRETO: Usar cores do banco de dados
color: props.$theme?.colors?.primary ||
  props.$theme?.colors?.secondary ||
  props.$theme?.colors?.accent;
```

**✅ VANTAGENS**:

- **Dinâmico**
- **Configurável**
- **Flexível**

---

## 🎯 **CRITÉRIOS DE SUCESSO**

### **✅ CRITÉRIO 1: Eliminação Total de Cores Hardcoded**

- **Meta**: 0 cores hardcoded
- **Métrica**: Busca por padrões de cores hardcoded

### **✅ CRITÉRIO 2: Adequação ao Tema**

- **Meta**: 100% das cores usando tema
- **Métrica**: Verificação de uso do tema

### **✅ CRITÉRIO 3: Adequação à Centralização**

- **Meta**: 100% das cores centralizadas
- **Métrica**: Verificação de uso do DEFAULT_COLORS

### **✅ CRITÉRIO 4: Adequação ao Banco de Dados**

- **Meta**: 100% das cores dinâmicas
- **Métrica**: Verificação de uso do banco de dados

---

## 🚀 **PRÓXIMOS PASSOS**

### **✅ PASSO 1: Implementar Fase 1**

- Analisar e priorizar arquivos
- Mapear dependências
- Criar cronograma

### **✅ PASSO 2: Implementar Fase 2**

- Corrigir design system
- Testar compatibilidade
- Validar funcionamento

### **✅ PASSO 3: Implementar Fases 3-5**

- Corrigir componentes e páginas
- Testar funcionalidade
- Validar UX/UI

### **✅ PASSO 4: Validação Final**

- Verificar critérios de sucesso
- Testar todos os cenários
- Documentar resultados

---

**Data da Pesquisa**: 08/01/2025  
**Status**: ✅ **PESQUISA CONCLUÍDA**  
**Próximo Passo**: Implementar correções seguindo o planejamento
