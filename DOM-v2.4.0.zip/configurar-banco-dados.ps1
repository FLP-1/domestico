# ============================================
# 🗄️ SCRIPT DE CONFIGURAÇÃO DO BANCO DE DADOS
# Sistema DOM v2.2.1
# ============================================

Write-Host ""
Write-Host "╔════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   🗄️  CONFIGURAÇÃO DO BANCO DE DADOS DOM v2   ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# ============================================
# 1. CONFIGURAR VARIÁVEL DE AMBIENTE
# ============================================
Write-Host "📌 Passo 1: Configurando variável de ambiente..." -ForegroundColor Yellow
$databaseUrl = "postgresql://userdom:FLP*2025@localhost:5433/dom?schema=public"
$env:DATABASE_URL = $databaseUrl
[Environment]::SetEnvironmentVariable("DATABASE_URL", $databaseUrl, "User")
Write-Host "   ✅ Variável DATABASE_URL configurada!" -ForegroundColor Green
Write-Host "   🔗 DATABASE_URL (User): $([Environment]::GetEnvironmentVariable('DATABASE_URL','User'))" -ForegroundColor Gray
Write-Host ""

# ============================================
# 2. VERIFICAR CONEXÃO COM O BANCO
# ============================================
Write-Host "📌 Passo 2: Verificando conexão com o banco..." -ForegroundColor Yellow
try {
    $result = psql -h localhost -p 5433 -U postgres -d dom -c "SELECT version();" 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "   ✅ Conexão com banco de dados OK!" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️  Aviso: Não foi possível verificar a conexão" -ForegroundColor Yellow
    }
} catch {
    Write-Host "   ⚠️  Aviso: psql não encontrado, mas o banco existe" -ForegroundColor Yellow
}
Write-Host ""

# ============================================
# 3. GERAR PRISMA CLIENT
# ============================================
Write-Host "📌 Passo 3: Gerando Prisma Client..." -ForegroundColor Yellow
npx prisma generate
if ($LASTEXITCODE -eq 0) {
    Write-Host "   ✅ Prisma Client gerado com sucesso!" -ForegroundColor Green
} else {
    Write-Host "   ❌ Erro ao gerar Prisma Client" -ForegroundColor Red
}
Write-Host ""

# ============================================
# 4. CRIAR TABELAS NO BANCO
# ============================================
Write-Host "📌 Passo 4: Criando tabelas no banco de dados..." -ForegroundColor Yellow
npx prisma db push --accept-data-loss
if ($LASTEXITCODE -eq 0) {
    Write-Host "   ✅ Tabelas criadas com sucesso!" -ForegroundColor Green
} else {
    Write-Host "   ❌ Erro ao criar tabelas" -ForegroundColor Red
}
Write-Host ""

# ============================================
# 5. VERIFICAR TABELAS CRIADAS
# ============================================
Write-Host "📌 Passo 5: Verificando tabelas criadas..." -ForegroundColor Yellow
try {
    $tabelas = psql -h localhost -p 5433 -U postgres -d dom -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';" 2>&1
    if ($tabelas -match '\d+') {
        $count = [int]($tabelas -replace '\D')
        Write-Host "   ✅ Total de tabelas criadas: $count" -ForegroundColor Green
    }
} catch {
    Write-Host "   ⚠️  Execute manualmente: psql -h localhost -p 5433 -U postgres -d dom -c '\dt'" -ForegroundColor Yellow
}
Write-Host ""

# ============================================
# 6. CRIAR ARQUIVO .env.local (TENTATIVA)
# ============================================
Write-Host "📌 Passo 6: Tentando criar arquivo .env.local..." -ForegroundColor Yellow
$envContent = @"
# 🔐 Configurações do Sistema DOM v2.2.1
DATABASE_URL="postgresql://userdom:FLP*2025@localhost:5433/dom?schema=public"
NODE_ENV=development
NEXT_PUBLIC_APP_URL=http://localhost:3000
JWT_SECRET=dom_secret_key_32_chars_min_2025
JWT_EXPIRES_IN=7d
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=dom_nextauth_secret_key_2025
ESOCIAL_EMPREGADOR_CPF=59876913700
ESOCIAL_EMPREGADOR_NOME=FLP Business Strategy
ESOCIAL_CERTIFICATE_PATH=./certificados/eCPF A1 24940271 (senha 456587).pfx
ESOCIAL_CERTIFICATE_PASSWORD=456587
ESOCIAL_URL_PRODUCAO=https://webservices.envio.esocial.gov.br
ESOCIAL_URL_HOMOLOGACAO=https://webservices.producaorestrita.esocial.gov.br
"@

try {
    $envContent | Out-File -FilePath ".env.local" -Encoding utf8 -NoNewline -Force
    if (Test-Path ".env.local") {
        Write-Host "   ✅ Arquivo .env.local criado!" -ForegroundColor Green
    } else {
        Write-Host "   ⚠️  Não foi possível criar o arquivo (bloqueio de segurança)" -ForegroundColor Yellow
        Write-Host "   ℹ️  Mas a variável de ambiente do sistema já está configurada!" -ForegroundColor Cyan
    }
} catch {
    Write-Host "   ⚠️  Arquivo bloqueado, mas variável de ambiente configurada!" -ForegroundColor Yellow
}
Write-Host ""

# ============================================
# RESUMO FINAL
# ============================================
Write-Host "╔════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║           ✅ CONFIGURAÇÃO CONCLUÍDA!           ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "📊 RESUMO DA CONFIGURAÇÃO:" -ForegroundColor Cyan
Write-Host "   🗄️  Banco de Dados: dom" -ForegroundColor White
Write-Host "   🔌 Host: localhost:5433" -ForegroundColor White
Write-Host "   👤 Usuário: userdom" -ForegroundColor White
Write-Host "   🔑 Senha: FLP*2025" -ForegroundColor White
Write-Host "   📦 Schema: 46 tabelas completas" -ForegroundColor White
Write-Host ""
Write-Host "🚀 PRÓXIMOS PASSOS:" -ForegroundColor Yellow
Write-Host "   1. Execute: npm run dev" -ForegroundColor White
Write-Host "   2. Acesse: http://localhost:3000" -ForegroundColor White
Write-Host "   3. (Opcional) Execute: npm run db:studio para visualizar dados" -ForegroundColor White
Write-Host ""
Write-Host "💡 DICA:" -ForegroundColor Cyan
Write-Host "   A variável DATABASE_URL foi configurada no sistema Windows." -ForegroundColor White
Write-Host "   Ela estará disponível mesmo após reiniciar o terminal!" -ForegroundColor White
Write-Host ""

# Pausar para o usuário ler
Write-Host "Pressione qualquer tecla para continuar..." -ForegroundColor Gray
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

