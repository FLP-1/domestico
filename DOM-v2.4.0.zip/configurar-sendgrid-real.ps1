# Configurar SendGrid REAL com conta Twilio existente

Write-Host "Configurando SendGrid com sua conta Twilio..." -ForegroundColor Cyan
Write-Host ""

# Ler o arquivo .env.local atual
$envFile = ".env.local"
if (Test-Path $envFile) {
    $envContent = Get-Content $envFile -Raw
    Write-Host "Arquivo .env.local encontrado" -ForegroundColor Green
} else {
    Write-Host "ERRO: Arquivo .env.local nao encontrado!" -ForegroundColor Red
    exit 1
}

# Verificar se já tem SENDGRID_API_KEY
if ($envContent -match "SENDGRID_API_KEY=SG\.") {
    Write-Host "SendGrid ja configurado no .env.local" -ForegroundColor Yellow
} else {
    Write-Host ""
    Write-Host "IMPORTANTE: Para usar SendGrid REAL, voce precisa:" -ForegroundColor Yellow
    Write-Host "1. Acessar: https://app.sendgrid.com/" -ForegroundColor White
    Write-Host "2. Fazer login com sua conta Twilio" -ForegroundColor White
    Write-Host "3. Ir em Settings > API Keys" -ForegroundColor White
    Write-Host "4. Criar nova API Key com permissoes de Mail Send" -ForegroundColor White
    Write-Host "5. Copiar a API Key gerada" -ForegroundColor White
    Write-Host ""

    # Solicitar API key
    $apiKey = Read-Host "Cole aqui sua API Key do SendGrid (SG.xxx)"

    if ($apiKey -and $apiKey.StartsWith("SG.")) {
        # Adicionar SendGrid ao .env.local
        $newEnvContent = $envContent + @"

# SENDGRID REAL CONFIGURADO
SENDGRID_API_KEY=$apiKey
SENDGRID_FROM_EMAIL=noreply@dom-sistema.com.br
SENDGRID_FROM_NAME=DOM Sistema eSocial
"@

        $newEnvContent | Out-File -FilePath $envFile -Encoding UTF8

        Write-Host ""
        Write-Host "SendGrid configurado com sucesso!" -ForegroundColor Green
        Write-Host "API Key: $($apiKey.Substring(0,8))..." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Reinicie o servidor para aplicar:" -ForegroundColor Cyan
        Write-Host "npm run dev" -ForegroundColor White

    } else {
        Write-Host ""
        Write-Host "API Key invalida. Deve comecar com SG." -ForegroundColor Red
        Write-Host "Exemplo: SG.abc123..." -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Status atual:" -ForegroundColor Cyan
Write-Host "SMS Twilio: FUNCIONANDO" -ForegroundColor Green
Write-Host "Email SendGrid: $(if ($envContent -match 'SENDGRID_API_KEY=SG\.') { 'CONFIGURADO' } else { 'PENDENTE' })" -ForegroundColor $(if ($envContent -match 'SENDGRID_API_KEY=SG\.') { 'Green' } else { 'Yellow' })
