// src/types.ts
export interface ProfileProps {
  id: string;
  nickname: string;
  role: string;
  group: string;
  color: string;
}
