# 🔍 ANÁLISE: CONSOLIDAÇÃO DE SISTEMAS DE TEMAS

## 📊 SISTEMAS EXISTENTES IDENTIFICADOS

### 1. `src/config/default-colors.ts`
- ❌ **Cores hardcoded** em `DEFAULT_COLORS`
- ❌ **Cores hardcoded** em `profiles` (empregado, empregador, etc.)
- ✅ Estrutura organizada

### 2. `src/config/theme.ts`
- ❌ **Cores hardcoded** em `colors`
- ✅ Estrutura bem definida
- ✅ Usado por `themeService.ts`

### 3. `src/config/centralized-config.ts`
- ✅ Busca do banco (`ConfiguracaoSistema`)
- ❌ **Fallback hardcoded** em `DEFAULT_CONFIG`
- ✅ Sistema funcional

### 4. `src/services/themeService.ts`
- ✅ Busca do banco (`TemaVisual`)
- ❌ **Fallback hardcoded** (`defaultTheme` de `config/theme.ts`)
- ✅ Cache implementado

### 5. `src/hooks/useTheme.ts`
- ❌ **Cores hardcoded** em `profileThemes`
- ✅ Integra com `useSystemConfig`
- ❌ Fallback usa cores hardcoded

### 6. `src/design-system/tokens/colors.ts`
- ❌ **Cores hardcoded** em `colors`
- ❌ **Cores hardcoded** em perfis
- ✅ Design system tokens

### 7. `src/utils/themeDefaults.ts`
- ❌ Usa `profileThemes` hardcoded
- ❌ **Cores hardcoded** em fallbacks

---

## 🎯 PROPOSTA: CONSOLIDAÇÃO EM UM ÚNICO SISTEMA

### Arquitetura Proposta:

```
src/services/themeService.ts (ÚNICO ARQUIVO)
├── Busca hierárquica:
│   1. Banco de Dados (Perfil.cor + ConfiguracaoPerfil)
│   2. Variáveis de Ambiente
│   3. null (não hardcoded)
├── Cache centralizado
├── Validação de cores
└── Geração de temas a partir de cor primária
```

### Fluxo de Fallback:

```
1. Perfil.cor (banco) + ConfiguracaoPerfil.colors (banco)
   ↓ (se não encontrar)
2. ConfiguracaoSistema.theme.colors (banco)
   ↓ (se não encontrar)
3. Variáveis de Ambiente (NEXT_PUBLIC_THEME_*)
   ↓ (se não encontrar)
4. null (componente decide como renderizar sem cor)
```

---

## ✅ BENEFÍCIOS

1. **Um único ponto de verdade** para cores
2. **Zero cores hardcoded** no código
3. **Configuração dinâmica** via banco de dados
4. **Fallback hierárquico** sem hardcoded
5. **Reutilizável** em todo o sistema
6. **Cache centralizado** para performance

---

## 📋 PLANO DE MIGRAÇÃO

### Fase 1: Consolidar em `themeService.ts`
- [ ] Expandir `themeService.ts` para buscar de Perfil
- [ ] Adicionar fallback para env vars
- [ ] Remover fallbacks hardcoded

### Fase 2: Atualizar dependências
- [ ] `useTheme.ts` → usar `themeService.ts`
- [ ] `themeHelpers.ts` → usar `themeService.ts`
- [ ] `themeDefaults.ts` → usar `themeService.ts`

### Fase 3: Deprecar arquivos antigos
- [ ] Marcar `default-colors.ts` como deprecated
- [ ] Marcar `design-system/tokens/colors.ts` como deprecated
- [ ] Migrar usos para `themeService.ts`

### Fase 4: Limpeza
- [ ] Remover arquivos deprecated
- [ ] Atualizar imports
- [ ] Validar funcionamento

---

## ⚠️ PONTOS DE ATENÇÃO

1. **Compatibilidade**: Garantir que componentes existentes continuem funcionando
2. **Performance**: Cache deve ser eficiente
3. **Validação**: Todas as cores devem ser validadas (hex válido)
4. **Fallback**: Componentes devem lidar com `null` graciosamente

