# Script para obter API Key do SendGrid via Twilio

Write-Host "🔑 Obtendo API Key do SendGrid para sua conta Twilio..." -ForegroundColor Cyan
Write-Host ""

# Credenciais do Twilio
$accountSid = "ACf606f29fe9619ee6b00310c43f4ee331"
$authToken = "b3bda417fc39081a0d92a4c2614bdc40"

Write-Host "📋 PASSOS PARA CONFIGURAR SENDGRID:" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. Acesse: https://console.twilio.com/" -ForegroundColor White
Write-Host "   Login com suas credenciais Twilio" -ForegroundColor Gray
Write-Host ""
Write-Host "2. No menu lateral, procure por 'SendGrid'" -ForegroundColor White
Write-Host "   Ou acesse: https://app.sendgrid.com/" -ForegroundColor Gray
Write-Host ""
Write-Host "3. Vá em Settings > API Keys" -ForegroundColor White
Write-Host "   Ou acesse: https://app.sendgrid.com/settings/api_keys" -ForegroundColor Gray
Write-Host ""
Write-Host "4. Clique em 'Create API Key'" -ForegroundColor White
Write-Host "   - Nome: DOM Sistema Email" -ForegroundColor Gray
Write-Host "   - Permissoes: Full Access ou Mail Send" -ForegroundColor Gray
Write-Host ""
Write-Host "5. Copie a API Key gerada (comeca com SG.)" -ForegroundColor White
Write-Host ""

# Aguardar input da API key
Write-Host "📝 Cole sua API Key do SendGrid aqui:" -ForegroundColor Cyan
$apiKey = Read-Host "API Key (SG.xxx)"

if ($apiKey -and $apiKey.StartsWith("SG.") -and $apiKey.Length -gt 20) {
    # Ler arquivo .env.local atual
    $envContent = Get-Content ".env.local" -Raw

    # Adicionar/atualizar configuração do SendGrid
    if ($envContent -match "# SENDGRID_API_KEY=") {
        # Substituir linha comentada
        $envContent = $envContent -replace "# SENDGRID_API_KEY=.*", "SENDGRID_API_KEY=$apiKey"
        $envContent = $envContent -replace "# SENDGRID_FROM_EMAIL=.*", "SENDGRID_FROM_EMAIL=noreply@dom-sistema.com.br"
        $envContent = $envContent -replace "# SENDGRID_FROM_NAME=.*", "SENDGRID_FROM_NAME=DOM Sistema eSocial"
    } else {
        # Adicionar no final
        $envContent += @"

# SENDGRID REAL CONFIGURADO
SENDGRID_API_KEY=$apiKey
SENDGRID_FROM_EMAIL=noreply@dom-sistema.com.br
SENDGRID_FROM_NAME=DOM Sistema eSocial
"@
    }

    # Salvar arquivo
    $envContent | Out-File -FilePath ".env.local" -Encoding UTF8

    Write-Host ""
    Write-Host "✅ SendGrid configurado com sucesso!" -ForegroundColor Green
    Write-Host "📧 API Key: $($apiKey.Substring(0,12))..." -ForegroundColor Yellow
    Write-Host "📤 From: noreply@dom-sistema.com.br" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "🔄 Reinicie o servidor para aplicar:" -ForegroundColor Cyan
    Write-Host "   Ctrl+C (parar servidor)" -ForegroundColor White
    Write-Host "   npm run dev (reiniciar)" -ForegroundColor White
    Write-Host ""
    Write-Host "🧪 Teste em: http://localhost:3000/teste-validacoes" -ForegroundColor Green

} else {
    Write-Host ""
    Write-Host "❌ API Key invalida!" -ForegroundColor Red
    Write-Host "Deve comecar com 'SG.' e ter mais de 20 caracteres" -ForegroundColor Yellow
    Write-Host "Exemplo: SG.abc123def456..." -ForegroundColor Gray
}

Write-Host ""
Write-Host "📞 Suporte: Se tiver problemas, verifique:" -ForegroundColor Cyan
Write-Host "- Conta Twilio ativa: https://console.twilio.com/" -ForegroundColor White
Write-Host "- SendGrid integrado: https://app.sendgrid.com/" -ForegroundColor White
