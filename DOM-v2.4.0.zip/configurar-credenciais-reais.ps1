# Script para Configurar Credenciais REAIS do DOM v2

Write-Host "Configurando credenciais REAIS do Twilio..." -ForegroundColor Cyan

# Verificar se o arquivo twilio.txt existe
$twilioFile = "certificados\twilio.txt"
if (Test-Path $twilioFile) {
    Write-Host "Arquivo twilio.txt encontrado" -ForegroundColor Green
} else {
    Write-Host "ERRO: Arquivo twilio.txt nao encontrado!" -ForegroundColor Red
    exit 1
}

# Criar arquivo .env.local com credenciais reais
$envContent = @'
# CREDENCIAIS REAIS DO TWILIO - SMS
TWILIO_ACCOUNT_SID=ACf606f29fe9619ee6b00310c43f4ee331
TWILIO_AUTH_TOKEN=b3bda417fc39081a0d92a4c2614bdc40
TWILIO_PHONE_NUMBER=+12183668060

# Credenciais de teste (backup)
TWILIO_TEST_ACCOUNT_SID=AC90c7149f08a3b642e6e083574a542da6
TWILIO_TEST_AUTH_TOKEN=0e9a4a9277c62a19258420b8673cf344

# CONFIGURACAO DE EMAIL - Configure uma das opcoes:

# Opcao 1: SendGrid (Twilio Email) - RECOMENDADO
# SENDGRID_API_KEY=SG.sua-api-key-real-aqui
# SENDGRID_FROM_EMAIL=noreply@seu-dominio.com
# SENDGRID_FROM_NAME=DOM Sistema

# Opcao 2: Gmail com senha de app
# EMAIL_USER=seu-email-real@gmail.com
# EMAIL_PASS=sua-senha-de-app-real

# Configuracoes do sistema
NODE_ENV=development
NEXT_PUBLIC_APP_URL=http://localhost:3000
'@

# Escrever arquivo
$envContent | Out-File -FilePath ".env.local" -Encoding UTF8

Write-Host ""
Write-Host "Arquivo .env.local criado com credenciais REAIS!" -ForegroundColor Green
Write-Host ""
Write-Host "PROXIMOS PASSOS:" -ForegroundColor Yellow
Write-Host "1. Configure uma opcao de email no .env.local"
Write-Host "2. Reinicie o servidor: npm run dev"
Write-Host "3. Teste em: http://localhost:3000/teste-validacoes"
Write-Host ""
Write-Host "SMS ja esta funcionando com credenciais reais!" -ForegroundColor Green
