-- AlterTable
ALTER TABLE "registros_ponto" ADD COLUMN     "endereco" TEXT;
